# Nemlig Assistant

This private plugin connects to the existing Nemlig MCP server at
`https://nemlig-mcp.broesby.dk/mcp`. The server advertises its OAuth resource
and authorization server. The package includes the repository's icon and a
shopping skill; it does not include credentials or server code. The upload ZIP
adds a snapshot of the canonical `wrangler.jsonc` as a restore reference; it
does not deploy it. The smaller `assets/connector-icon.png` is derived from the
same icon for ChatGPT's custom MCP registration form.

`plugin.json` is the portable plugin manifest. `.app.json` binds this package
to the registered ChatGPT MCP app; `mcp.json` names the remote Streamable HTTP
server for portable clients. The skill under `skills/` describes the shopping
flow and its add-only basket boundary. New product choices stay in an unsaved
conversation draft. Explicit Save creates a native Nemlig shopping list;
explicit Update persists staged list edits. Submission uses the exact reviewed
list and verifies additive basket readback before deleting its source list.
An uncertain result must be inspected, never blindly retried. The source for
the server, deployment, and OAuth configuration remains in the Everyday
Assistants repository and its configured providers.

Installing the package does not prove that OAuth, tool discovery, or the
interactive UI works. Verify those separately in a fresh ChatGPT Work
conversation. Search and basket viewing are read-only. A real basket addition
requires the server's exact preparation, authorization, apply, and readback
flow. Never remove or reduce actual basket items, check out, or pay through
this plugin.
